package DAOs;

import Entidades.Compra;
import java.util.ArrayList;
import java.util.List;
import static DAOs.DAOGenerico.em;
import java.text.SimpleDateFormat;

public class DAOCompra extends DAOGenerico<Compra> {

    public DAOCompra() {
        super(Compra.class);
    }

    public int autoIdCompra() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.id) FROM Compra e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Compra> listById(int id) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.id = :id").setParameter("id", id).getResultList();
    }

    public List<Compra> listByClienteCpf(int clienteCpf) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.clienteCpf LIKE :clienteCpf").setParameter("clienteCpf", "%" + clienteCpf + "%").getResultList();
    }

    public List<Compra> listInOrderId() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.id").getResultList();
    }

    public List<Compra> listInOrderClienteCpf() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.clienteCpf").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Compra> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderClienteCpf();
        }

        List<String> ls = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < lf.size(); i++) {
        }
        return ls;
    }
}

