package DAOs;

import Entidades.ProdutosCompra;
import java.util.ArrayList;
import java.util.List;
import static DAOs.DAOGenerico.em;
import java.text.SimpleDateFormat;

public class DAOProdutosCompra extends DAOGenerico<ProdutosCompra> {

    public DAOProdutosCompra() {
        super(ProdutosCompra.class);
    }

    public int autoIdProdutosCompra() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.produtoId) FROM ProdutosCompra e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<ProdutosCompra> listByProdutoId(int produtoId) {
        return em.createQuery("SELECT e FROM ProdutosCompra e WHERE e.produtoId = :produtoId").setParameter("produtoId", produtoId).getResultList();
    }

    public List<ProdutosCompra> listByCompraId(int compraId) {
        return em.createQuery("SELECT e FROM ProdutosCompra e WHERE e.compraId LIKE :compraId").setParameter("compraId", "%" + compraId + "%").getResultList();
    }

    public List<ProdutosCompra> listInOrderProdutoId() {
        return em.createQuery("SELECT e FROM ProdutosCompra e ORDER BY e.produtoId").getResultList();
    }

    public List<ProdutosCompra> listInOrderCompraId() {
        return em.createQuery("SELECT e FROM ProdutosCompra e ORDER BY e.compraId").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<ProdutosCompra> lf;
        if (qualOrdem.equals("produtoId")) {
            lf = listInOrderProdutoId();
        } else {
            lf = listInOrderCompraId();
        }

        List<String> ls = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < lf.size(); i++) {
        }
        return ls;
    }
}

