package DAOs;

import Entidades.Cliente;
import java.util.ArrayList;
import java.util.List;
import static DAOs.DAOGenerico.em;
import java.text.SimpleDateFormat;

public class DAOCliente extends DAOGenerico<Cliente> {

    public DAOCliente() {
        super(Cliente.class);
    }

    public int autoIdCliente() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.cpf) FROM Cliente e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Cliente> listByCpf(int cpf) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.cpf = :cpf").setParameter("cpf", cpf).getResultList();
    }

    public List<Cliente> listByTelefone(String telefone) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.telefone LIKE :telefone").setParameter("telefone", "%" + telefone + "%").getResultList();
    }

    public static List<Cliente> listInOrderCpf() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.cpf").getResultList();
    }

    public static List<Cliente> listInOrderTelefone() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.telefone").getResultList();
    }

    public static List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Cliente> lf;
        if (qualOrdem.equals("cpf")) {
            lf = listInOrderCpf();
        } else {
            lf = listInOrderTelefone();
        }

        List<String> ls = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getCpf() + ";" + lf.get(i).getTelefone() + ";" + lf.get(i).getNome() + ";" + lf.get(i).getEmail() + ";" + lf.get(i).getEndereco() + ";" + lf.get(i).getStatus() + ";");
        }
        return ls;
    }
    
    
}

