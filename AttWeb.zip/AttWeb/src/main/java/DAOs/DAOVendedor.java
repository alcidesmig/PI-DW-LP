package DAOs;

import Entidades.Vendedor;
import java.util.ArrayList;
import java.util.List;
import static DAOs.DAOGenerico.em;
import java.text.SimpleDateFormat;

public class DAOVendedor extends DAOGenerico<Vendedor> {

    public DAOVendedor() {
        super(Vendedor.class);
    }

    public int autoIdVendedor() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.id) FROM Vendedor e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Vendedor> listById(int id) {
        return em.createQuery("SELECT e FROM Vendedor e WHERE e.id = :id").setParameter("id", id).getResultList();
    }

    public List<Vendedor> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Vendedor e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Vendedor> listInOrderId() {
        return em.createQuery("SELECT e FROM Vendedor e ORDER BY e.id").getResultList();
    }

    public List<Vendedor> listInOrderNome() {
        return em.createQuery("SELECT e FROM Vendedor e ORDER BY e.nome").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Vendedor> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < lf.size(); i++) {
        }
        return ls;
    }
}

