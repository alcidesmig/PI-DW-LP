/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Entidades.Endereco;
import Entidades.Pessoa;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author alcides
 */
@WebServlet(urlPatterns = {"/ServletColecao"})
public class ServletColecao extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Endereco endereco = new Endereco("873002220", "Centro");
        Pessoa pessoa = new Pessoa("Alcides", "Sobrenome", endereco);
        request.setAttribute("pessoa", pessoa);
        List estados = new ArrayList<>();
        estados.add("1");
        estados.add("2");
        estados.add("3");
        estados.add("4");
        estados.add("5");
        estados.add("6");
        estados.add("7");
        estados.add("8");
        estados.add("9");
        estados.add("10");
        request.setAttribute("estados", estados);

        Map capitais = new HashMap();
        capitais.put("1", "Mapa 1");
        capitais.put("2", "Mapa 2");
        capitais.put("3", "Mapa 3");
        capitais.put("4", "Mapa 4");
        capitais.put("5", "Mapa 5");
        capitais.put("6", "Mapa 6");
        capitais.put("7", "Mapa 7");
        capitais.put("8", "Mapa 8");
        capitais.put("9", "Mapa 9");
        capitais.put("10", "Mapa 10");

        HttpSession sessao = request.getSession();
        sessao.setAttribute("capitais", capitais);

        RequestDispatcher rd = request.getRequestDispatcher("/resultado3.jsp");
        rd.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
