/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author user
 */
@Entity
@Table(name = "produto")
@NamedQueries({
    @NamedQuery(name = "Produto.findAll", query = "SELECT p FROM Produto p")})
public class Produto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "preco")
    private double preco;
    @Basic(optional = false)
    @NotNull
    @Column(name = "qtd_estoque")
    private int qtdEstoque;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "nome")
    private String nome;
    @JoinColumn(name = "categoria_nome", referencedColumnName = "nome")
    @ManyToOne(optional = false)
    private Categoria categoriaNome;
    @JoinColumn(name = "fornecedor_id", referencedColumnName = "id")
    @ManyToOne
    private Fornecedor fornecedorId;
    @JoinColumn(name = "marca_nome", referencedColumnName = "nome")
    @ManyToOne(optional = false)
    private Marca marcaNome;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "produto")
    private List<ProdutosCompra> produtosCompraList;

    public Produto() {
    }

    public Produto(Integer id) {
        this.id = id;
    }

    public Produto(Integer id, double preco, int qtdEstoque, String nome) {
        this.id = id;
        this.preco = preco;
        this.qtdEstoque = qtdEstoque;
        this.nome = nome;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(int qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Categoria getCategoriaNome() {
        return categoriaNome;
    }

    public void setCategoriaNome(Categoria categoriaNome) {
        this.categoriaNome = categoriaNome;
    }

    public Fornecedor getFornecedorId() {
        return fornecedorId;
    }

    public void setFornecedorId(Fornecedor fornecedorId) {
        this.fornecedorId = fornecedorId;
    }

    public Marca getMarcaNome() {
        return marcaNome;
    }

    public void setMarcaNome(Marca marcaNome) {
        this.marcaNome = marcaNome;
    }

    public List<ProdutosCompra> getProdutosCompraList() {
        return produtosCompraList;
    }

    public void setProdutosCompraList(List<ProdutosCompra> produtosCompraList) {
        this.produtosCompraList = produtosCompraList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Produto)) {
            return false;
        }
        Produto other = (Produto) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Produto[ id=" + id + " ]";
    }
    
}
